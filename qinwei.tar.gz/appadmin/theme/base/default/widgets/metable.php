<?php
use appadmin\assets\DataTablesAsset;
DataTablesAsset::register($this);
?>
<?=$metable;?>