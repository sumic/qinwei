<?php
Yii::setAlias('@uploads', '@appimage');//文件上传目录
Yii::setAlias('@article', '@uploads/article');//文章相关资源上传目录
Yii::setAlias('@thumb', '@article/thumb');//文章缩略图上传目录
Yii::setAlias('@ueditor', '@uploads/ueditor');//文章ueditor编辑器资源上传目录
Yii::setAlias('@friendlylink', '@uploads/friendlylink');//友情链接图片上传目录
Yii::setAlias('@voices', '@uploads/voices');//录音文件上传目录
