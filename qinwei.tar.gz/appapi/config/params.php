<?php
return [
    'admin_verifyCode' => false, //是否验证验证码
];
